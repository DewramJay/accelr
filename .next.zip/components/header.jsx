
const Header = () => {
    return (
      <header style={{ padding: '20px', backgroundColor: '#f8f8f8' }}>
        <h1>My Website</h1>
      </header>
    );
  };
  
  export default Header;